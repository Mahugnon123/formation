@extends("front.app")
@section("content")

<?php 
$besoin=json_decode($formation->besoin);
$contenu=json_decode($formation->Contenu);
$competence=json_decode($formation->competence);

 ?>
<!-- page title -->
<section class="page-title-section overlay" data-background="../theme/images/backgrounds/page-title.jpg">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ul class="list-inline custom-breadcrumb mb-2">
          <li class="list-inline-item"><a class="h2 text-primary font-secondary" href="/">Accueil</a></li>
          <li class="list-inline-item text-white h3 font-secondary nasted">{{$formation->titre}}</li>
        </ul>
        <p class="text-lighten mb-0">{{$formation->description}}</p>
      </div>
    </div>
  </div>
</section>
<!-- /page title -->

<!-- section -->
<section class="section-sm">
  <div class="container">
    <div class="row">
      <div class="col-12 mb-4">
        <!-- course thumb -->
        <img src="{{asset($formation->image_url)}}" class="img-fluid w-100">
      </div>
    </div>
    <!-- course info -->
    <div class="row align-items-center mb-5">
      <div class="col-xl-3 order-1 col-sm-6 mb-4 mb-xl-0">
        <h2>{{$formation->titre}}</h2>
      </div>
      <div class="col-xl-6 order-sm-3 order-xl-2 col-12 order-2">
        <ul class="list-inline text-xl-center">
          <li class="list-inline-item mr-4 mb-3 mb-sm-0">
            <div class="d-flex align-items-center">
              <i class="ti-book text-primary icon-md mr-2"></i>
              <div class="text-left">
                <h6 class="mb-0">Durée de la formation</h6>
                <p class="mb-0">{{$formation->duree}}</p>
              </div>
            </div>
          </li>
          <!-- <li class="list-inline-item mr-4 mb-3 mb-sm-0">
            <div class="d-flex align-items-center">
              <i class="ti-alarm-clock text-primary icon-md mr-2"></i>
              <div class="text-left">
                <h6 class="mb-0">DURATION</h6>
                <p class="mb-0">03 Hours</p>
              </div>
            </div>
          </li> -->
          <li class="list-inline-item mr-4 mb-3 mb-sm-0">
            <div class="d-flex align-items-center">
              <i class="ti-wallet text-primary icon-md mr-2"></i>
              <div class="text-left">
                <h6 class="mb-0">Prix de la formation</h6>
                @if($formation->prix_formation==null)
                 <p class="mb-0">0 FCFA</p>
                 @else
                 <p class="mb-0">one_formation->prix_formation fcfa</p>
                 @endif
                <!-- <p class="mb-0">From: $699</p> -->
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div class="col-xl-3 text-sm-right text-left order-sm-2 order-3 order-xl-3 col-sm-6 mb-4 mb-xl-0">
        <a href="/course-single" class="btn btn-primary">S'inscrire</a>
      </div>
      <!-- border -->
      <div class="col-12 mt-4 order-4">
        <div class="border-bottom border-primary"></div>
      </div>
    </div>
    <!-- course details -->
    <div class="row">
      <div class="col-12 mb-4">
        <h3>A PROPOS DE LA FORMATION</h3>
        <p>{{$formation->a_propos}}</p>
      </div>
      <div class="col-12 mb-12">
        <h3 class="mb-3">LES PREREQUIS</h3>
        <div class="col-12 px-0">
          <div class="row">
            <div class="col-md-12">
              <ul class="list-styled">
                @foreach($besoin as $one_besoin)
                <li>{{$one_besoin->value}}</li>
                @endforeach
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <div class="col-12 mb-4">
        <h3 class="mb-3">CE QUE VOUS ALLEZ APPRENDRE</h3>
        <ul class="list-styled">
          @foreach($contenu as $one_contenu)
          <li>{{$one_contenu->value}}</li>
          @endforeach
        </ul>
      </div>

      <div class="col-12 mb-4">
        <h3 class="mb-3">COMPÉTENCES QUE VOUS ACQUERREZ</h3>
        <ul class="list-styled">
          @foreach($competence as $one_competence)
          <li>{{$one_competence->value}}</li>
          @endforeach
        </ul>
      </div>
      
      <!-- teacher -->
      <div class="col-12">
        <h5 class="mb-3">A PROPOS DE L'ENSEIGNAT</h5>
        <div class="d-flex justify-content-between align-items-center flex-wrap">
          <div class="media mb-2 mb-sm-0">
            <img class="mr-4 img-fluid" src="{{asset($enseignant->photo_profil)}}" width="30%;" alt="Teacher">
            <div class="media-body">
              <h4 class="mt-0">{{$enseignant->nom}}</h4>
              {{$enseignant->prenom}}
            </div>
          </div>
          <div class="social-link">
            <h6 class="d-none d-sm-block">Reseaux</h6>
            <ul class="list-inline">
              <li class="list-inline-item"><a class="d-inline-block text-light p-1" href="https://themefisher.com/"><i class="ti-facebook"></i></a></li>
              <li class="list-inline-item"><a class="d-inline-block text-light p-1" href="https://themefisher.com/"><i class="ti-twitter-alt"></i></a></li>
              <li class="list-inline-item"><a class="d-inline-block text-light p-1" href="https://themefisher.com/"><i class="ti-linkedin"></i></a></li>
              <li class="list-inline-item"><a class="d-inline-block text-light p-1" href="https://themefisher.com/"><i class="ti-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="border-bottom border-primary mt-4"></div>
      </div>
    </div>
  </div>
</section>
<!-- /section -->

<!-- related course -->
<!-- <section class="section pt-0">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <h2 class="section-title">Related Course</h2>
      </div>
    </div>
    <div class="row justify-content-center">
      
      <div class="col-lg-4 col-sm-6 mb-5">
        <div class="card p-0 border-primary rounded-0 hover-shadow">
          <img class="card-img-top rounded-0" src="../theme/images/courses/course-1.jpg" alt="course thumb">
          <div class="card-body">
            <ul class="list-inline mb-2">
              <li class="list-inline-item"><i class="ti-calendar mr-1 text-color"></i>02-14-2018</li>
              <li class="list-inline-item"><a class="text-color" href="/course-single">Humanities</a></li>
            </ul>
            <a href="course-single">
              <h4 class="card-title">Photography</h4>
            </a>
            <p class="card-text mb-4"> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
              incididunt ut labore et dolore magna.</p>
            <a href="course-single" class="btn btn-primary btn-sm">Apply now</a>
          </div>
        </div>
      </div>
      
      <div class="col-lg-4 col-sm-6 mb-5">
        <div class="card p-0 border-primary rounded-0 hover-shadow">
          <img class="card-img-top rounded-0" src="../theme/images/courses/course-2.jpg" alt="course thumb">
          <div class="card-body">
            <ul class="list-inline mb-2">
              <li class="list-inline-item"><i class="ti-calendar mr-1 text-color"></i>02-14-2018</li>
              <li class="list-inline-item"><a class="text-color" href="course-single">Humanities</a></li>
            </ul>
            <a href="/course-single">
              <h4 class="card-title">Programming</h4>
            </a>
            <p class="card-text mb-4"> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
              incididunt ut labore et dolore magna.</p>
            <a href="/course-single" class="btn btn-primary btn-sm">Apply now</a>
          </div>
        </div>
      </div>
     
      <div class="col-lg-4 col-sm-6 mb-5">
        <div class="card p-0 border-primary rounded-0 hover-shadow">
          <img class="card-img-top rounded-0" src="../theme/images/courses/course-3.jpg" alt="course thumb">
          <div class="card-body">
            <ul class="list-inline mb-2">
              <li class="list-inline-item"><i class="ti-calendar mr-1 text-color"></i>02-14-2018</li>
              <li class="list-inline-item"><a class="text-color" href="course-single">Humanities</a></li>
            </ul>
            <a href="/course-single">
              <h4 class="card-title">Lifestyle Archives</h4>
            </a>
            <p class="card-text mb-4"> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
              incididunt ut labore et dolore magna.</p>
            <a href="course-single" class="btn btn-primary btn-sm">Apply now</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> -->
<!-- /related course -->


@endsection
</body>
</html>