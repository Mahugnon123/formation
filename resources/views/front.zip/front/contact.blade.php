@extends("front.app")
@section("content")
<!-- page title -->
<section class="page-title-section overlay" data-background="../theme/images/backgrounds/page-title.jpg">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ul class="list-inline custom-breadcrumb mb-2">
          <li class="list-inline-item"><a class="h2 text-primary font-secondary" href="index">Accueil</a></li>
          <li class="list-inline-item text-white h3 font-secondary nasted">Nous contacter</li>
        </ul>
      <!--   <p class="text-lighten mb-0">Our courses offer a good compromise between the continuous assessment favoured by some universities and the emphasis placed on final exams by others.</p> -->
      </div>
    </div>
  </div>
</section>
<!-- /page title -->

<!-- contact -->
<section class="section bg-gray">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2 class="section-title">Nous contacter</h2>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-7 mb-4 mb-lg-0">
        <form action="/contact" method="POST">
          <input type="text" class="form-control mb-3" id="name" name="name" placeholder="Votre nom" required>
          <input type="email" class="form-control mb-3" id="mail" name="mail" placeholder="Votre Email" required>
          <input type="text" class="form-control mb-3" id="subject" name="subject" placeholder="Sujet" required>
          <textarea name="message" id="message" class="form-control mb-3" placeholder="Votre Message" required></textarea>
          <button type="submit" value="send" class="btn btn-primary">ENVOYER</button>
        </form>
      </div>
      <div class="col-lg-5">
        <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit recusandae voluptates doloremque veniam temporibus porro culpa ipsa, nisi soluta minima saepe laboriosam debitis nesciunt. Dolore, labore. Accusamus nulla sed cum aliquid exercitationem debitis error harum porro maxime quo iusto aliquam dicta modi earum fugiat, vel possimus commodi, deleniti et veniam, fuga ipsum praesentium. Odit unde optio nulla ipsum quae obcaecati! Quod esse natus quibusdam asperiores quam vel, tempore itaque architecto ducimus expedita</p>
        <a href="tel:+8802057843248" class="text-color h5 d-block">(+229)</a>
        <a href="mailto:yourmail@email.com" class="mb-5 text-color h5 d-block">contact@sinustic.com</a>
      </div>
    </div>
  </div>
</section>
<!-- /contact -->

<!-- gmap -->
<section class="section pt-0">
  <!-- Google Map -->
 <!--  <div id="map_canvas" data-latitude="51.507351" data-longitude="-0.127758"></div> -->
</section>
<!-- /gmap -->

@endsection
</body>
</html>