@extends('Apprenant.app')
@section('content')

<div class="w-4/5 m-auto text-center">
    <div class="border-gray-200 py-15 border-h">
        <h1 class="text-5xl">Note des chapitres du resume : {{$resume->titre}} </h1>
    </div>


    @if (session()->has('message'))

        <div class="w-4/5 pl-2 m-auto mt-10">
            <p class="w-1/6 py-4 mb-4 bg-green-500 text-gray-50 rounded-2xl">
                {{session()->get('message')}}
        </p>

        </div>
    @endif
    <div class="container  mt-5">
        <div class="row">
        @foreach($resume->resumeChapitre as $key=> $value){
            
           <div class="card m-3" style="width: 18rem;">
                    <img src="images/note.jpeg"  class="card-img-top"  alt="...">
                    <div class="card-body">
                        <h5 class="card-title text-primary"> $value['nom']
                                            </h5>
                        <p class="card-text">Commentaire</p>
                        <span class="text-gray-500">
                           Created on 02/juin/2022
                        </span>
                        <div class="row">
                            <p class="col">
                                <a href="" data-bs-toggle="modal" data-bs-target="#popup">
                                <i class="bi bi-pencil-square"></i><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="indigo" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                </svg> Modifier
                                </a>
                                <a href="">
                                    <form action=""
                                        method="POST">

                                        @csrf 
                                        
                                        @method('delete')
                                
                                <button type="submit"  class="btn btn-link btn-sm btn-rounded">
                                <i class="bi bi-trash3"></i>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-trash3" viewBox="0 0 16 16">
                                    <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5ZM11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H2.506a.58.58 0 0 0-.01 0H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1h-.995a.59.59 0 0 0-.01 0H11Zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5h9.916Zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47ZM8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5Z"/>
                                </svg>Supprimer 
                                </button>
                                </form>
                                </a>
                            </p>
                        </div>

                    </div>

                <!-- Pop-up -->
                <div id="popup" class="modal">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <p> Nom du chapitre</p>
                            </div>
                            <form action="" method="post">
                            @csrf
                                <div class="modal-body">
                                    <textarea name="commentaire" id="" cols="50" rows="10" value="Commentaire" required="required"> Commentaires</textarea>
                                </div>
                            <input type="hidden" name="id" value="">
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-secondary" data-dismiss="modal">Valider</button>
                            </div>
                            </form>

                        </div>
                    </div>
                </div>
                </div>
            </div>
            @endforeach
        </div>

    

@endsection