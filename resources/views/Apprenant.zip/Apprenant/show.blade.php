@extends("Apprenant.app")
@section("content")

@if (session()->has('message'))

        <div class="py-2 mt-3">
            <p class=" py-4 mb-4 bg-sucess text-info rounded-2xl">
                {{session()->get('message')}}
        </p>

        </div>
    @endif

<div class="container">
    <div class="row d-flex justify-content-center mt-5 mb-5 bg-white">
        
        <div class="col-md-6">
            
            <div class="card p-4">
                
                <div class="text-left">
                    <h2> Votre Profil </h2>
                    <span> {{ucfirst($user->apropos)}} </span>
                </div>
                 
                <form action="/show-user" method="post">
                    @csrf
                <div class="form-row">
                    <div class="col">
                        <label>Nom</label>
                        <input type="text" class="form-control" required="required" name="nom" value="{{ ucfirst($user->nom)}}">
                    </div>
                    <div class="col">
                        <label>Prenom</label>
                        <input type="text" class="form-control" required="required" name="prenom" value="{{ ucfirst($user->prenom)}}">
                    </div>
                </div>
                
                <div class="row">
                    <div class="form">
                        <label>Pays</label>
                        <input type="text" class="form-control" required="required" name="pays" value="{{ ucfirst($user->pays)}}">
                    </div>
                    <div class="form">
                        <label>Email</label>
                        <input type="email" class="form-control" required="required" name="email" value="{{ ucfirst($user->email)}}">
                    </div>
                </div>
                
                <div class="mt-2">
                    <div class="form">
                        <label>Date de naissance</label>
                        <input type="date"  required="required" name="birthday" class="form-control">
                    </div>
                </div>
                
                <div class="mt-2">
                    <div class="form">
                        <label>Telephone</label>
                        <div class="phone">
                        <input type="text" required="required" name="phone" class="form-control" value="{{ ucfirst($user->contact)}}" required="required">
                        </div>
                    </div>
                </div>
                
                <div class="mt-3">
                    <button type="submit" class="button btn btn-primary w-100 d-flex justify-content-center align-items-center"><span>Modifier</span><i class="fa fa-long-arrow-right ms-2"></i></button>
                </div>
                
            </div>
            
        </div>
        <div class="col-md-6">
           
        <img
              src= "images/person.png"
              alt="person"
              style="width: 400px; height: 400px"
              class="rounded-circle"
              />
        </div>
        
    </div>
</div>

</form>
@endsection